class Maillon:
    def __init__(self, tete, queue):
        """
        Crée une instance de la classe Maillon.
        - Entrées : tete (type quelconque), queue (instance de la classe Liste)
        """
        self._tete = tete
        self._queue = queue

class Liste:
    def __init__(self, maillon):
        """
        Crée une instance de la classe Liste.
        - Entrée : maillon (instance de la classe Maillon, ou None pour créer une liste vide)
        """
        self.maillon = maillon

    def est_vide(self):
        """
        Détermine si la liste est vide.
        - Sortie : (booléen, True si la liste est vide, False sinon)
        """
        return self.maillon is None

    def tete(self):
        """
        Retourne la première valeur de la liste.
        - Sortie : None si la liste est vide, sinon la valeur située à l'indice 0 dans la liste
        """
        if self.est_vide():
            return None
        else:
            return self.maillon._tete

    def queue(self):
        """
        Retourne la queue de la liste, c'est-à-dire la liste privée de son premier maillon.
        - Sortie : (instance de la classe Liste)
        """
        if self.est_vide():
            raise ValueError('la liste est vide')
        else:
            return self.maillon._queue

    def nb_elements(self):
        """
        Compte le nombre d'éléments de la liste.
        - Sortie : (entier, nombre de valeurs présentes dans la liste)
        """
        if self.est_vide():
            return 0
        else:
            liste = self.queue()
            return 1 + liste.nb_elements()

    def inserer_en_tete(self, elem):
        """
        Insère un maillon en début de liste.
        - Entrée : elem (type quelconque)
        """
        self.maillon = Maillon(elem, Liste(self.maillon))

    def supprimer_en_tete(self):
        """
        Supprime un maillon en début de liste.
        """
        if self.est_vide():
            raise ValueError('la liste est vide')
        else:
            self.maillon = self.queue().maillon

    def inserer(self, elem, pos):
        """
        Insère un maillon dans la liste en position pos.
        - Entrée : elem (type quelconque), pos (entier)
        """
        if pos > self.nb_elements():
            raise IndexError('la liste ne contient pas assez d\'éléments')
        liste = self
        for _ in range(pos):
             liste = liste.queue()
        liste.inserer_en_tete(elem)

    def supprimer(self, pos):
        """
        Supprime un maillon dans la liste en position pos.
        - Entrée : pos (entier)
        """
        if pos >= self.nb_elements():
            raise IndexError('la liste ne contient pas assez d\'éléments')
        liste = self
        for _ in range(pos):
            liste = liste.queue()
        liste.supprimer_en_tete()

    def renverser(self):
        """
        Renverse l'ordre des éléments de la liste.
        """
        p1 = Pile()
        while not self.est_vide():
            p1.empiler(self.tete())
            self.supprimer_en_tete()
        p2 = Pile()
        while not p1.est_vide():
            p2.empiler(p1.depiler())
        while not p2.est_vide():
            self.inserer_en_tete(p2.depiler())
        
    def __str__(self):
        """
        Permet l'affichage des éléments de la liste via un appel à la fonction print.
        """
        chaine = ""
        liste = self
        for k in range(self.nb_elements()):
            chaine = chaine + f"{liste.tete()}  "
            liste = liste.queue()
        return chaine


class Pile:
    def __init__(self):
        """
        Crée une pile vide.
        """
        self.liste = Liste(None)
    
    def est_vide(self):
        """
        Détermine si la pile est vide.
        - Sortie : (booléen, True si la pile est vide, False sinon)
        """
        return self.liste.est_vide()
    
    def empiler(self, elem):
        """
        Ajoute un élément au sommet de la pile.
        - Entrée : elem (type quelconque, élément à ajouter)
        """
        self.liste.inserer_en_tete(elem)
    
    def depiler(self):
        """
        Retire l'élément au sommet de la pile et le renvoie.
        - Sortie : elem (type quelconque, élément à retirer)
        """
        if self.est_vide():
            raise ValueError('la pile est vide')
        elem = self.liste.tete()
        self.liste.supprimer_en_tete()
        return elem
    
    def __str__(self):
        """
        Permet l'affichage des éléments de la pile via un appel à la fonction print.
        """
        return '(sommet)  ' + str(self.liste) + '(bas)'


class File:
    def __init__(self):
        """
        Crée une file vide.
        """
        self.liste = Liste(None)
    
    def est_vide(self):
        """
        Détermine si la file est vide.
        - Sortie : (booléen, True si la file est vide, False sinon)
        """
        return self.liste.est_vide()
    
    def enfiler(self, elem):
        """
        Ajoute un élément à la fin de la file.
        - Entrée : elem (type quelconque, élément à ajouter)
        """
        n = self.liste.nb_elements()
        self.liste.inserer(elem, n)
    
    def defiler(self):
        """
        Retire l'élément au début de la file et le renvoie.
        - Sortie : elem (type quelconque, élément à retirer)
        """
        if self.est_vide():
            raise ValueError('la file est vide')
        elem = self.liste.tete()
        self.liste.supprimer_en_tete()
        return elem
    
    def __str__(self):
        """
        Permet l'affichage des éléments de la pile via un appel à la fonction print.
        """
        return '(sortie)  ' + str(self.liste) + '(entrée)'
 
if __name__ == '__main__':
    L = Liste(None)
    for k in range(10):
        L.inserer_en_tete(k)
    print(L)
    L.renverser()
    print(L)
    P = Pile()
    for k in range(20):
        P.empiler(k**2)
    print(P)
    for k in range(10):
        P.depiler()
    print(P)
    F = File()
    for k in range(20):
        F.enfiler(k**2)
    print(F)
    for k in range(10):
        F.defiler()
    print(F)
