try:
    from graphviz import Digraph, Graph
except:
    print('Problème d\'importation de graphviz')

class GrapheOriente:
    def __init__(self, param):
        if type(param) == int:
            self.init_depuis_entier(param)
        elif type(param) == list:
            self.init_depuis_matrice(param)
        elif type(param) == dict:
            self.init_depuis_dico(param)
        else:
            raise TypeError('l\'argument doit être un entier, un tableau à deux dimensions ou un dictionnaire')

    def init_depuis_entier(self, taille):
        self.taille = taille
        self.liste_voisins = {k : [] for k in range(taille)}
        self.etiquette_sommet = {k : str(k) for k in range(taille)}
        self.mat = [[0 for _ in range(taille)] for _ in range(taille)]
        self.poids_arcs = False

    def ajouter_arc(self, i, j, val=1):
        self.liste_voisins[i].append((j, val))   
        self.mat[i][j] = val
        if val != 1:
            self.poids_arcs = True

    def init_depuis_matrice(self, mat):
        self.taille = len(mat)
        self.liste_voisins = {k : [] for k in range(self.taille)}
        self.etiquette_sommet = {k : str(k) for k in range(self.taille)}
        self.mat = [[0 for _ in range(self.taille)] for _ in range(self.taille)]
        self.poids_arcs = False
        for i in range(self.taille):
            for j in range(self.taille):
                if mat[i][j] != 0:
                    self.ajouter_arc(i, j, mat[i][j])

    def init_depuis_dico(self, dico):
        self.taille = len(dico)
        self.liste_voisins = {k : [] for k in range(self.taille)}
        self.etiquette_sommet = {k : str(k) for k in range(self.taille)}
        self.mat = [[0 for _ in range(self.taille)] for _ in range(self.taille)]
        self.poids_arcs = False
        for i in dico:
            for x in dico[i]:
                if type(x) == int:
                    self.ajouter_arc(i, x)
                else:
                    self.ajouter_arc(i, x[0], x[1])

    def nommer_sommet(self, k, nom):
        self.etiquette_sommet[k] = nom

    def matrice(self):
        return self.mat

    def dictionnaire(self):
        return self.liste_voisins

    def afficher(self, couleurs=None, fichier=None):
        self.dot = Digraph(engine='neato', format='png')
        for i in range(self.taille):
            self.dot.node(str(i), self.etiquette_sommet[i], shape='circle', style='filled', fillcolor=couleurs[i] if couleurs else 'white')
            for (j, val) in self.liste_voisins[i]:
                if self.poids_arcs:
                    self.dot.edge(str(i), str(j), label=str(val), fontsize='10.0')
                else:
                    self.dot.edge(str(i), str(j))
        if fichier:
            self.dot.render(fichier)
        return self.dot


class Graphe(GrapheOriente):
    def ajouter_arete(self, i, j, val=1):
        self.ajouter_arc(i, j, val)
        self.ajouter_arc(j, i, val)
        
    def afficher(self, couleurs=None, fichier=None):
        self.dot = Graph(engine='neato', format='png')
        for i in range(self.taille):
            self.dot.node(str(i), self.etiquette_sommet[i], shape='circle', style='filled', fillcolor=couleurs[i] if couleurs else 'white')
            for (j, val) in self.liste_voisins[i]:
                if j >= i :
                    if self.poids_arcs:
                        self.dot.edge(str(i), str(j), label=str(val), fontsize='10.0')
                    else:
                        self.dot.edge(str(i), str(j))
        if fichier:
            self.dot.render(fichier)
        return self.dot
