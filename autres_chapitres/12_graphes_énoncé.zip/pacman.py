from PIL import Image
from structures_lineaires import File
from time import sleep
import pygame
from pygame.locals import *


class GrillePacman:
    def __init__(self, fichier_image, nb_l, nb_c):
        """
        Crée une grille de jeu.
        - Entrées : fichier_image (chaîne, nom d'un fichier image),
                    nb_l, nb_c (entiers, nombre de lignes et de colonnes dans la grille)
        """
        self.fichier_image = fichier_image
        self.nb_l, self.nb_c = nb_l, nb_c
        self.tab, self.t_c = self._creer_tableau(self.fichier_image)
        self.dico_LC_n, self.dico_n_LC = self._grille_vers_dictionnaires()
        self.graphe = self._grille_vers_graphe()

    def _creer_tableau(self, fichier_image):
        """
        Récupère la grille de jeu à l'intérieur d'une image en noir et blanc.
        - Entrée : fichier_image (chaîne, nom d'un fichier image)
        - Sorties : tab (tableau à deux dimensions), taille_case (entier, taille des cases carrées en pixels)
        """
        image = Image.open(fichier_image).convert('RGB')
        largeur, hauteur = image.size
        taille_case = largeur // self.nb_c
        tab = []
        for L in range(self.nb_l):
            ligne = []
            for C in range(self.nb_c):
                coul = image.getpixel(((C+0.5)*taille_case, (L+0.5)*taille_case)) # Couleur du pixel au centre de la case (L, C)
                ligne.append(coul == (255, 255, 255)) # On ajoute True si la case est blanche, False sinon
            tab.append(ligne)
        return tab, taille_case
        
    def case_blanche(self, pos):
        """
        Détermine si une case est un passage ou non.
        - Entrée : pos (couple au format (L, C))
        - Sortie : (booléen, True si la case en position pos est un passage, False si c'est un mur)
        """
        L, C = pos
        return self.tab[L][C]
            
    def _grille_vers_dictionnaires(self):
        """
        Définit deux dictionnaires permettant la correspondance entre numéro de case blanche (n) et position de la case (L, C).
        - Sortie : dico_LC_n, dico_n_LC (dictionnaires, permettant les conversions (L, C) -> n et n -> (L, C) respectivement
        """
        dico_LC_n = {}
        dico_n_LC = {}
        n = 0
        for L in range(len(self.tab)):
            for C in range(len(self.tab[L])):
                if self.tab[L][C]:
                    dico_LC_n[(L, C)] = n
                    dico_n_LC[n] = (L, C)
                    n = n + 1
        return dico_LC_n, dico_n_LC

    def _grille_vers_graphe(self):
        """
        Calcule le dictionnaire d'adjacence du graphe associé à la grille.
        - Sortie : dico_adjacence (dictionnaire d'adjacence)
        """
        haut, larg = len(self.tab), len(self.tab[0])
        dico_adjacence = {}
        for (L, C) in self.dico_LC_n:
            dico_adjacence[self.dico_LC_n[(L, C)]] = []
            for (L2, C2) in [((L-1)%larg, C%haut), ((L+1)%larg, C%haut), (L%larg, (C-1)%haut), (L%larg, (C+1)%haut)]:
                if self.tab[L2][C2]:
                    dico_adjacence[self.dico_LC_n[(L, C)]].append(self.dico_LC_n[(L2, C2)])
        return dico_adjacence

    def recherche_chemin(self, pos_depart, pos_objectif):
        """
        Détermine quelle case voisine de pos_objectif est la plus proche de pos_depart. 
        - Entrées : pos_depart, pos_objectif (couples de la forme (L, C))
        - Sortie : (couple de la forme (L, C), correspondant à la position où se rendre pour se rapprocher du départ)
        Remarque : Dans le cas où l'objectif n'est pas atteignable à partir du départ, la fonction renvoie None.
        """
        return pos_objectif # Supprimer cette ligne et implémenter la méthode recherche_chemin !

    def ouvrir_fenetre(self):
        """
        Ouvre une fenêtre pygame aux dimensions de la grille de jeu.
        """
        pygame.init()
        pygame.display.init()
        self.fen = pygame.display.set_mode((self.nb_c*self.t_c, self.nb_l*self.t_c))
        pygame.display.set_caption('Pacman')
        self.fond = pygame.image.load(self.fichier_image).convert()

    def afficher_perso(self, perso):
        """
        Affiche un personnage dans la fenêtre pygame.
        - Entrée : perso (instance de la classe Personnage)
        """
        L, C = perso.pos
        angle = {'H' : 90, 'B' : 270, 'G' : 180, 'D' : 0}[perso.dir]
        if angle:
            sprite = pygame.transform.rotate(perso.sprite, angle)
        else:
            sprite = perso.sprite
        self.fen.blit(sprite, (C*self.t_c, L*self.t_c))
    
    def actualiser_fenetre(self, *args, terreur=False):
        """
        Actualise la fenêtre en y affichant la grille et des personnages.
        - Entrées : args (instance(s) de la classe Personnage séparées par des virgules, personnages à afficher),
                    terreur (booléen, True pour faire clignotter la fenêtre en rouge avant de l'afficher)
        """
        if terreur:
            self.fen.fill((255, 0,  0))
            pygame.display.update()
            sleep(0.05)
        self.fen.blit(self.fond, (0, 0))
        for perso in args:
	        self.afficher_perso(perso)
        pygame.display.update()

    def fermer_fenetre(self):
        """
        Ferme la fenêtre pygame.
        """
        sleep(1)
        pygame.display.quit()
        

class Personnage:
    def __init__(self, grille, fichier_image, pos):
        """
        Crée un personnage du jeu Pacman.
        - Entrées : grille (instance de la classe GrillePacman),
                    fichier_image (chaîne, nom d'un fichier image),
                    pos (couple de la forme (L, C), position initiale du personnage)
        """
        self.sprite = pygame.transform.scale(pygame.image.load(fichier_image).convert_alpha(), (grille.t_c, grille.t_c))
        self.pos = pos
        self.dir = 'D'
    
    def _choix_deplacement(self):
        """
        Permet le choix d'une direction à l'aide des touches directionnelles du clavier.
        - Sortie : (caractères parmi 'G', 'D', 'H', 'B', indiquant une direction)
        Attention : l'exécution du programme est interrompue en attendant qu'une des quatre touches directionnelles ait été pressée.
        """
        while True:
            pygame.time.Clock().tick(30)
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_LEFT:
                        return 'G'
                    elif event.key == K_RIGHT:
                        return 'D'
                    elif event.key == K_UP:
                        return 'H'
                    elif event.key == K_DOWN:
                        return 'B'

    def deplacer(self, grille):
        """
        Déplace le personnage dans une direction choisie à l'aide d'une touche directionnelle, si ce déplacement est possible.
        - Entrée : grille (instance de la classe GrillePacman)
        """
        L, C = self.pos
        self.dir = self._choix_deplacement()
        if self.dir == 'H':
            nouv_L, nouv_C = (L-1)%grille.nb_l, C%grille.nb_c
        elif self.dir == 'B':
            nouv_L, nouv_C = (L+1)%grille.nb_l, C%grille.nb_c
        elif self.dir == 'G':
            nouv_L, nouv_C = L%grille.nb_l, (C-1)%grille.nb_c
        elif self.dir == 'D':
            nouv_L, nouv_C = L%grille.nb_l, (C+1)%grille.nb_c
        if grille.case_blanche((nouv_L, nouv_C)):
            self.pos = (nouv_L, nouv_C)
        

if __name__ == '__main__':
    grille = GrillePacman('Images/pacman2.png', 19, 19)
    grille.ouvrir_fenetre()
    pacman = Personnage(grille, 'Images/sprite_pacman.png', (1, 1))
    fantome = Personnage(grille, 'Images/sprite_fantome.png', (1, 17))
    while pacman.pos != fantome.pos:
        grille.actualiser_fenetre(pacman, fantome)
        pacman.deplacer(grille)
        if pacman.pos != fantome.pos:
            fantome.pos, dist = grille.recherche_chemin(pacman.pos, fantome.pos)
    grille.actualiser_fenetre(pacman, fantome)
    grille.fermer_fenetre()
