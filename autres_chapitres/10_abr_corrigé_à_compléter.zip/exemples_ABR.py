from structures_hierarchiques import Noeud, ArbreBinaire

# Arbre Binaire de Recherche alphabet latin

Lsa_1 = Noeud('D', Noeud('B', Noeud('A'), Noeud('C')), Noeud('E', None, Noeud('F')))
Lsa_2 = Noeud('K', Noeud('I', Noeud('H'), Noeud('J')), Noeud('L', None, Noeud('N', Noeud('M'), None)))
Lsa_3 = Noeud('Q', Noeud('P'), Noeud('R'))
Lsa_4 = Noeud('X', Noeud('U', Noeud('T'), Noeud('W', Noeud('V'), None)), Noeud('Y', None, Noeud('Z')))
alpha_lat = ArbreBinaire(Noeud('O', Noeud('G', Lsa_1, Lsa_2), Noeud('S', Lsa_3, Lsa_4)))

# Arbre Binaire de Recherche alphabet grec    

Gsa_1 = Noeud('Δ', Noeud('Β', Noeud('Α'), Noeud('Γ')), Noeud('Ζ', Noeud('Ε'), Noeud('Η')))
Gsa_2 = Noeud('Κ', Noeud('Ι'), Noeud('Λ'))
Gsa_3 = Noeud('Π', Noeud('Ξ', Noeud('Ν'), Noeud('Ο')), Noeud('Σ', Noeud('Ρ'), Noeud('Τ')))
Gsa_4 = Noeud('Ψ', Noeud('Χ', Noeud('Φ'), None), Noeud('Ω'))
alpha_grc = ArbreBinaire(Noeud('Μ', Noeud('Θ', Gsa_1, Gsa_2), Noeud('Υ', Gsa_3, Gsa_4)))

# Arbre Binaire de Recherche entiers compris entre 0 et 12

sa_1 = Noeud(1, Noeud(0), Noeud(2))
sa_2 = Noeud(4, None, Noeud(5))
sa_3 = Noeud(8, Noeud(7), None)
sa_4 = Noeud(11, Noeud(10), Noeud(12))
arbre = ArbreBinaire(Noeud(6, Noeud(3, sa_1, sa_2), Noeud(9, sa_3, sa_4)))

# Arbre Binaire de Recherche entiers

sa_1 = Noeud(5, Noeud(3, Noeud(1), Noeud(4)), Noeud(8, Noeud(7), Noeud(9)))
sa_2 = Noeud(15, Noeud(12, Noeud(11), Noeud(14)), Noeud(17, Noeud(16), Noeud(19)))
sa_3 = Noeud(25, Noeud(22, Noeud(21), Noeud(24)), Noeud(28, Noeud(27), Noeud(29)))
sa_4 = Noeud(35, Noeud(33, Noeud(31), Noeud(34)), Noeud(38, Noeud(36), Noeud(39)))
arbre = ArbreBinaire(Noeud(20, Noeud(10, sa_1, sa_2), Noeud(30, sa_3, sa_4)))
