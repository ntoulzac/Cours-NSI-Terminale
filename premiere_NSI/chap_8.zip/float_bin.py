import struct

NORMAL = "\033[0;0m"
NOIR_GRAS = "\033[1;30m"
ROUGE_GRAS = "\033[1;31m"
BLEU_GRAS = "\033[1;34m"
VERT_GRAS = "\033[1;32m"

def bin32(num):
    return [bin(c).replace('0b', '').rjust(8, '0') for c in struct.pack('!f', num)]

def float_bin32(num):
    bits = ''.join(bin32(num))
    return VERT_GRAS + bits[0] + ROUGE_GRAS + bits[1:9] + BLEU_GRAS + bits[9:] + NORMAL

def bin64(num):
    return [bin(c).replace('0b', '').rjust(8, '0') for c in struct.pack('!d', num)]

def float_bin64(num):
    bits = ''.join(bin64(num))
    return VERT_GRAS + bits[0] + ROUGE_GRAS + bits[1:12] + BLEU_GRAS + bits[12:] + NORMAL
