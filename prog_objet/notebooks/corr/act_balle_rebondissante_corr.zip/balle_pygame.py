import pygame

NOIR = (0, 0, 0)
BLANC = (255, 255, 255)

def ouvrir_fenetre(largeur, hauteur):
	fenetre = pygame.display.set_mode((largeur, hauteur))
	fenetre.fill(BLANC)
	pygame.display.update()
	return fenetre

def actualiser(fenetre, balle):
	fenetre.fill(BLANC)
	pygame.draw.rect(fenetre, NOIR, (balle.x, balle.y, balle.taille, balle.taille))
	pygame.display.update()

def fermer_fenetre():
	pygame.quit()
