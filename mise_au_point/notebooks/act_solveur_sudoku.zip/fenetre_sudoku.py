import pygame
from pygame.locals import QUIT as _QUIT, KEYUP as _KEYUP, K_ESCAPE as _K_ESCAPE, MOUSEBUTTONUP as _MOUSEBUTTONUP
pygame.init()
pygame.font.init()

NOIR = (0, 0, 0)
BLANC = (255, 255, 255)
COULEUR = (124, 215, 66)

class FenetreSudoku:
    """
    Classe permettant de gérer une fenêtre pygame pour l'affichage d'une grille de sudoku.
    """
    def __init__(self, taille_case):
        """
        Ouvre une fenêtre pygame aux dimensions d'une grille de Sudoku
        (9 lignes et 9 colonnes), plus une zone de texte en bas.
        - Entrée : taille_case (entier, taille en pixels d'une case de la grille)
        """
        self.t_c = taille_case
        pygame.display.init()
        self.police = pygame.font.SysFont('Courier New', self.t_c//2)
        self.fen = pygame.display.set_mode((9*self.t_c, 10*self.t_c))
        pygame.display.set_caption('Solveur de Sudoku')

    def fermer(self):
        """
        Ferme la fenêtre pygame.
        """
        pygame.display.quit()

    def _afficher_grille(self, sud):
        """
        Affiche dans la fenêtre pygame les frontières des cases de la grille,
        et en couleur les cases dont la valeur est donnée dès le départ.
        - Entrée : sud (instance de la classe Sudoku)
        """
        def epaisseur(n):
            if n % 3 == 0:
                return self.t_c//15
            else:
                return self.t_c//30
        for num_lig in range(9):
            for num_col in range(9):
                if sud.grille_init[9*num_lig + num_col] != 0:
                    pygame.draw.rect(self.fen, COULEUR, (num_col*self.t_c, num_lig*self.t_c, self.t_c, self.t_c))
        for num in range(1, 9):
            ep = epaisseur(num)
            pygame.draw.line(self.fen, NOIR, (num*self.t_c-ep/2, 0), (num*self.t_c-ep/2, 9*self.t_c), ep)
            pygame.draw.line(self.fen, NOIR, (0, num*self.t_c-ep/2), (9*self.t_c, num*self.t_c-ep/2), ep)
        
    def _afficher_chiffres(self, sud):
        """
        Affiche dans la fenêtre pygame des valeurs de la grille de sudoku.
        - Entrée : sud (instance de la classe Sudoku)
        """
        for i in range(81):
            if sud.grille[i] != 0:
                if sud.grille_init[i] != 0:
                    couleur_fond = COULEUR
                else:
                    couleur_fond = BLANC
                texte = self.police.render(str(sud.grille[i]), True, NOIR, couleur_fond)
                self.fen.blit(texte, ((0.5+i%9)*self.t_c-texte.get_width()/2, (0.5+i//9)*self.t_c-texte.get_height()/2))

    def _afficher_texte(self, texte):
        """
        Affiche un texte en bas de la fenêtre pygame.
        - Entrée : texte (chaîne de caractères)
        """
        pygame.draw.rect(self.fen, NOIR, (0, 9*self.t_c, 9*self.t_c, self.t_c))
        texte = self.police.render(texte, True, BLANC, NOIR)
        self.fen.blit(texte, (4.5*self.t_c-texte.get_width()/2, 9.5*self.t_c-texte.get_height()/2))

    def effacer(self):
        """
        Efface la fenêtre pygame en la remplissant de blanc.
        """
        self.fen.fill(BLANC)
    
    def actualiser(self, sud, texte):
        """
        Affiche dans la fenêtre pygame une grille de sudoku et un texte.
        - Entrées : sud (instance de la classe Sudoku), texte (chaîne de caractères)
        """
        self._afficher_grille(sud)
        self._afficher_chiffres(sud)
        self._afficher_texte(texte)
        pygame.display.flip()

    def attendre_clic(self):
        """
        Met le programme en attente d'un clic à la souris ou de l'appui sur une touche.
        Permet à l'utilisateur de décider entre continuer ou s'arrêter.
        - Sortie : (booléen, False pour s'arrêter, en cas de fermeture de la fenêtre ou d'appui sur Echap,
                             True pour continuer, en cas d'appui sur une autre touche ou de clic à la souris)
        """
        while True:
            pygame.time.Clock().tick(30)
            for event in pygame.event.get():
                if event.type == _QUIT or event.type == _KEYUP and event.key == _K_ESCAPE:
                    return False
                elif event.type == _KEYUP or event.type == _MOUSEBUTTONUP:
                    return True
